#!/bin/sh -x

# install ansible
DEBIAN_FRONTEND=noninteractive sudo apt-get -y install ansible
