# Changelog

## [qemu-0.4.1] - 2022-01-27
### Fixed
- Hostname is added on boot to /etc/hosts [#4](https://gitlab.ics.muni.cz/muni-kypo-images/debian-10/-/issues/4)

## [qemu-0.4.0], [vbox-0.4.0] - 2021-08-17
### Changed
- Debian version from 10.8 to 10.10

## [qemu-0.3.1], [vbox-0.3.1] - 2021-03-01
### Fixed
- Python 3.9 pip and Python3.9 modules

## [qemu-0.3.0], [vbox-0.3.0] - 2021-02-23
### Changed
- Debian version from 10.6 to 10.8
- Python version to 3.9.1
- Ansible version to 2.10

## [qemu-0.2.0], [vbox-0.2.0] - 2021-02-05
### Added
- This CHANGELOG file and CI/CD
### Changed
- Debian version from 10.4 to 10.6

## [qemu-0.1.0], [vbox-0.1.0] - 2020-05-20
### Changed
- Debian version from 10.3 to 10.4

[qemu-0.1.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/5b4eca0432b967149339ad3682bba2ba5278e190
[vbox-0.1.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/5b4eca0432b967149339ad3682bba2ba5278e190
[qemu-0.2.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/qemu-0.2.0
[vbox-0.2.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/vbox-0.2.0
[qemu-0.3.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/qemu-0.3.0
[vbox-0.3.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/vbox-0.3.0
[qemu-0.3.1]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/qemu-0.3.1
[vbox-0.3.1]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/vbox-0.3.1
[qemu-0.4.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/qemu-0.4.0
[vbox-0.4.0]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/vbox-0.4.0
[qemu-0.4.1]: https://gitlab.ics.muni.cz/muni-kypo-images/debian-10-amd64/-/tree/qemu-0.4.1
