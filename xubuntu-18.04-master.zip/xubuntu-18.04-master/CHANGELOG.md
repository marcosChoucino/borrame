# Changelog

## [qemu-0.2.3], [vbox-0.2.3] - 2022-07-28
### Added
- Copy paste function of VNC is enabled on GUI startup

## [qemu-0.2.1] - 2022-01-29
### Fixed
- Hostname is added on boot to /etc/hosts

## [qemu-0.2.0], [vbox-0.2.0] - 2021-12-01
### Added
- VNC server for guacamole access

## [qemu-0.1.0], [vbox-0.1.0] - 2020-08-10
### Added
- First version


[qemu-0.1.0]: https://gitlab.ics.muni.cz/muni-kypo-images/xubuntu-18.04/-/tree/105a49d8
[vbox-0.1.0]: https://gitlab.ics.muni.cz/muni-kypo-images/xubuntu-18.04/-/tree/105a49d8
[qemu-0.2.0]: https://gitlab.ics.muni.cz/muni-kypo-images/xubuntu-18.04/-/tree/qemu-0.2.0
[vbox-0.2.0]: https://gitlab.ics.muni.cz/muni-kypo-images/xubuntu-18.04/-/tree/vbox-0.2.0
[qemu-0.2.1]: https://gitlab.ics.muni.cz/muni-kypo-images/xubuntu-18.04/-/tree/qemu-0.2.1
[qemu-0.2.3]: https://gitlab.ics.muni.cz/muni-kypo-images/xubuntu-18.04/-/tree/qemu-0.2.3
[vbox-0.2.3]: https://gitlab.ics.muni.cz/muni-kypo-images/xubuntu-18.04/-/tree/vbox-0.2.3
