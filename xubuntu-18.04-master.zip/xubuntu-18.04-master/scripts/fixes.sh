#!/bin/bash -x

# disable root login using password
sudo passwd -l root

